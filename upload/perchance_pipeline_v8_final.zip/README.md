# Perchance Blitz Pipeline v8 — Final

> AI Image Generation Automation via Selenium + Undetected Chrome
> Permanent Token · Flat Iframe · Chrome 143 · Xvfb Headed
> **15-18 seconds** cold start to first image

---

## Overview

This pipeline automates Perchance AI image generation. It launches a stealthy Chrome browser via Selenium, navigates to a Perchance generator using a permanent API token (which bypasses Cloudflare instantly), enters prompts, clicks generate, and saves resulting images to disk.

### How It Works

```
Python Script
  → Xvfb (virtual display :99)
    → Chrome 143 (headed, undetected)
      → perchance.org/mqgfwnim7o?apiToken=YOUR_TOKEN
        → Generator iframe (flat structure — images appear here)
          → <img src="data:image/jpeg;base64,...">  ← captured and saved
```

### Performance Breakdown

| Step | Time |
|---|---|
| Process cleanup + Xvfb launch | ~2.0s |
| Chrome 143 launch | ~0.9s |
| Cloudflare bypass (API token) | ~0.3s |
| Generator iframe load | ~4.0s |
| Prompt entry + generate click | ~1.5s |
| Image generation (Perchance server) | ~10s |
| Image decode + save | ~0.5s |
| **Total (cold start to first image)** | **~15-18s** |

---

## System Requirements

### Operating System
- **Linux** (Ubuntu 20.04+, Debian 11+, CentOS 7+)
- Headless server is fine — Xvfb provides a virtual display

### Software Dependencies

| Dependency | Version | Purpose |
|---|---|---|
| Python | 3.9+ (3.12+ recommended) | Script runtime |
| Google Chrome | **143** (exact) | Browser automation target |
| ChromeDriver | **143** (must match Chrome) | WebDriver for Selenium |
| Xvfb | Any recent | Virtual display for headed Chrome |
| pip packages | See below | Python libraries |

### Python Packages

```
pip install undetected-chromedriver selenium setuptools
```

**CRITICAL: `setuptools` is REQUIRED on Python 3.13+**

Python 3.13 removed `distutils` from the standard library. The `undetected-chromedriver` package depends on `distutils` internally and will crash silently without `setuptools` (which provides the `distutils` compatibility shim). Installing `setuptools` fixes this and drops Chrome launch time from 30-45 seconds to ~1 second.

---

## Installation

### Step 1: Install System Dependencies

**Ubuntu/Debian:**
```bash
sudo apt update
sudo apt install -y xvfb python3 python3-pip wget unzip
```

**CentOS/RHEL:**
```bash
sudo yum install -y xorg-x11-server-Xvfb python3 python3-pip wget unzip
```

### Step 2: Install Chrome 143

```bash
# Create directory
mkdir -p ~/chrome-bin

# Download Chrome 143 for Linux (64-bit)
cd ~/chrome-bin
wget -q "https://storage.googleapis.com/chrome-for-testing-public/143.0.0.0/linux64/chrome-linux64.zip"
unzip -q chrome-linux64.zip
mv chrome-linux64 chrome-143

# Download matching ChromeDriver 143
wget -q "https://storage.googleapis.com/chrome-for-testing-public/143.0.0.0/linux64/chromedriver-linux64.zip"
unzip -q chromedriver-linux64.zip

# Verify
~/chrome-bin/chrome-143/chrome-linux64/chrome --version
# Should output: Chrome 143.0.xxxx.xx
```

**If the above URLs don't work**, check the official Chrome for Testing dashboard:
https://googlechromelabs.github.io/chrome-for-testing/

### Step 3: Install Python Packages

```bash
pip install undetected-chromedriver selenium setuptools
```

### Step 4: Configure the Pipeline

Edit `perchance_pipeline.py` and update these values in the CONFIGURATION section:

```python
# Chrome binary path (must match your installation)
CHROME_BIN = "/home/z/chrome-bin/chrome-143/chrome-linux64/chrome"

# ChromeDriver path (must match your installation)
CHROMEDRIVER = "/home/z/chrome-bin/chromedriver-linux64/chromedriver"

# Your Perchance generator slug
GENERATOR = "mqgfwnim7o"

# Your permanent API token
API_TOKEN = "perm-agent-token-7h3k9p2q"

# Output directory for generated images
OUTPUT_DIR = "./perchance_output"
```

### Step 5: Test

```bash
python3 perchance_pipeline.py "a cute cat, photorealistic, 8k"
```

If everything works, you should see output like:
```
16:30:00 [INFO] Navigating to generator...
16:30:00 [INFO]   URL: https://perchance.org/mqgfwnim7o?apiToken=perm-agent-token-7h3k9p2q
16:30:00 [INFO] Chrome 143 browser ready (headed via Xvfb)
16:30:01 [INFO] Cloudflare bypassed in 0.3s
16:30:05 [INFO] Generator iframe ready in 4.3s
16:30:06 [INFO] Prompt entered: "a cute cat, photorealistic, 8k"
16:30:07 [INFO] Generate button clicked
16:30:07 [INFO] Generation triggered at 5.7s — waiting for images...
16:30:17 [INFO]   Image #1: 124KB saved at 15.6s
16:30:17 [INFO] Generation complete: 1 image(s) in 15.8s

  SUCCESS: 1 image(s) generated in 15.8s
  Output directory: /home/z/perchance_output

    perchance_20260607_163000_01.jpg  (124KB)
```

---

## Usage

### Basic Usage

```bash
# Generate with a text prompt (default: 2 images)
python3 perchance_pipeline.py "a beautiful sunset over mountains"

# Generate a specific number of images
python3 perchance_pipeline.py "anime girl, silver hair" --count 4

# Custom output directory
python3 perchance_pipeline.py "cyberpunk city" --output ./my_art
```

### Prompt Templates

Built-in templates for common use cases:

```bash
python3 perchance_pipeline.py --template portrait
python3 perchance_pipeline.py --template fullbody
python3 perchance_pipeline.py --template spicy
python3 perchance_pipeline.py --template landscape
python3 perchance_pipeline.py --template cyberpunk
python3 perchance_pipeline.py --template fantasy
```

### Prompt from File

```bash
# Create a file with your prompt
echo "a serene Japanese garden with koi pond, morning mist, photorealistic, 8k" > my_prompt.txt

# Generate using the file
python3 perchance_pipeline.py --prompt-file my_prompt.txt
```

### Advanced Options

```bash
# Wait up to 90 seconds for slow generation
python3 perchance_pipeline.py "complex scene" --wait 90

# Require larger images (50KB minimum)
python3 perchance_pipeline.py "portrait" --min-size 50000

# Combine multiple options
python3 perchance_pipeline.py "anime warrior" --count 4 --wait 90 --output ./warriors
```

### All CLI Options

```
positional arguments:
  prompt                Image generation prompt (text)

optional arguments:
  --template, -t        Use a built-in prompt template
                        Choices: portrait, fullbody, spicy, landscape, cyberpunk, fantasy
  --prompt-file, -f     Read prompt from a text file
  --count, -n           Number of unique images to collect (default: 2)
  --output, -o          Output directory for images (default: ./perchance_output)
  --wait, -w            Max seconds to wait for images (default: 60)
  --min-size            Minimum image size in bytes (default: 20000)
```

---

## Warmup Script

The warmup script (`perchance_warmup.py`) keeps the pipeline session active by running safe prompts periodically. This is useful when you want instant generation (no cold-start penalty).

### What It Does

- Launches Chrome with the same settings as the main pipeline
- Navigates to the generator
- Enters a random safe prompt
- Clicks generate
- Waits for generation to start (doesn't save images)
- Cleans up all processes

### Running as a Cron Job (Every 8 Minutes)

```bash
# Edit crontab
crontab -e

# Add this line (adjust paths to match your setup):
*/8 * * * * cd /home/z/perchance_pipeline_v8 && python3 -u perchance_warmup.py >> warmup.log 2>&1
```

---

## Troubleshooting

### Chrome fails to launch / takes 30+ seconds

**Cause:** Missing `setuptools` on Python 3.13+

**Fix:**
```bash
pip install setuptools
```

This is the #1 issue. Python 3.13 removed `distutils`, and `undetected-chromedriver` crashes silently during import without it.

### Cloudflare blocks access / "Just a moment" page

**Possible causes:**
1. **No API token** — Make sure `API_TOKEN` is set correctly in the config
2. **Headless mode** — The pipeline uses Xvfb + headed mode. Do NOT add `--headless` flag
3. **Wrong Chrome version** — Must be exactly Chrome 143 matching the ChromeDriver

### No images found after generate

**Possible causes:**
1. **Wrong iframe structure** — This pipeline is designed for `mqgfwnim7o` which has a FLAT iframe (images appear directly in the generator iframe). If using a different generator, you may need to adjust the iframe navigation logic
2. **Generation too slow** — Increase `--wait` to 90 or 120
3. **Image too small** — Lower `--min-size` to 10000

### Chrome processes not dying / port conflicts

**Fix:** Kill manually:
```bash
pkill -9 -x chrome
pkill -9 -x chromedriver
pkill -9 -x Xvfb
```

### Xvfb display already in use

**Fix:**
```bash
# Kill existing Xvfb
pkill -9 -x Xvfb

# Or use a different display number
# Edit XVFB_DISPLAY in the script to ":98" or ":100"
```

---

## File Structure

```
perchance_pipeline_v8/
├── perchance_pipeline.py    # Main pipeline script
├── perchance_warmup.py      # Warmup script for cron jobs
├── README.md                # This file
└── perchance_output/        # Generated images (auto-created)
    └── perchance_*.jpg       # Generated images
```

---

## Technical Notes

### Why Xvfb + Headed Chrome?

Perchance is protected by Cloudflare's anti-bot system. Headless Chrome is detected ~70% of the time and blocked. Running Chrome in "headed" mode behind Xvfb (a virtual framebuffer that provides a display without a physical monitor) makes the browser appear as a real desktop Chrome instance. This combined with `undetected-chromedriver` achieves near-100% CF bypass rate.

### Why API Token?

Without an API token, Cloudflare shows a challenge page that requires JavaScript execution and cookie validation, adding 5-30 seconds. The API token (`?apiToken=YOUR_TOKEN`) bypasses this entirely — the page loads directly with no challenge.

### Flat vs Nested Iframe Structure

Different Perchance generators have different iframe architectures:
- **Nested (old generators like `zahid-aistudio`):** page → generator iframe → image-generation iframe → images
- **Flat (new generators like `mqgfwnim7o`):** page → generator iframe → images (directly)

This pipeline is built for the flat structure. If you use a generator with nested iframes, you'll need to add an extra `driver.switch_to.frame()` step after clicking generate to enter the `image-generation` sub-iframe before polling.

### Image Format

Perchance outputs images as base64-encoded data URIs embedded in `<img>` elements. The pipeline decodes these and saves them as JPEG or PNG files depending on the MIME type.

---

## Version History

| Version | Changes |
|---|---|
| v1-v3 | Initial prototypes, basic Selenium automation |
| v4 | Xvfb + headed Chrome, stable CF bypass |
| v5 | Persistent Chrome profile for faster warmup |
| v6 | NG toggle disable for unrestricted content |
| v7 | API token integration, `setuptools` fix, 1s Chrome launch |
| **v8** | **Permanent token, new generator (mqgfwnim7o), flat iframe fix, 15-18s generation** |

---

Built by Lumiere ◈ — June 2026
