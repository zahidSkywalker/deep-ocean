#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  PERCHANCE BLITZ PIPELINE v8 — FINAL                                      ║
║  Permanent Token · Flat Iframe · Chrome 143 · Xvfb Headed                  ║
║  15-18s cold start → first image                                           ║
╚══════════════════════════════════════════════════════════════════════════════╝

Author: Lumière ◈
Version: 8.0 Final
Date: June 2026

WHAT THIS DOES:
    Automates Perchance AI image generation via Selenium + undetected-chromedriver.
    Bypasses Cloudflare instantly using an API token, navigates the generator's
    iframe structure, enters prompts, clicks generate, and saves resulting images.

KEY DISCOVERY:
    Generator mqgfwnim7o uses a FLAT iframe structure — images appear directly
    inside the generator iframe. No nested "image-generation" sub-iframe needed.
    (Old generators like zahid-aistudio had 3+ nested iframe layers.)

PERFORMANCE:
    Cold start to first image: 15-18 seconds
    - Process cleanup + Xvfb:     ~2.0s
    - Chrome launch:             ~0.9s
    - CF bypass (API token):     ~0.3s
    - Generator iframe load:     ~4.0s
    - Prompt entry + generate:   ~1.5s
    - Image generation (Perchance server): ~10s
    - Image capture + save:      ~0.5s

USAGE:
    python3 perchance_pipeline.py "a beautiful sunset landscape"
    python3 perchance_pipeline.py "anime girl portrait" --count 4
    python3 perchance_pipeline.py --prompt-file prompt.txt --count 2
    python3 perchance_pipeline.py --template spicy --ng --count 4

REQUIREMENTS:
    - Python 3.9+ (3.12+ recommended)
    - Google Chrome 143 (exact version required)
    - ChromeDriver matching Chrome 143
    - undetected-chromedriver (pip package)
    - setuptools (CRITICAL for Python 3.13+ — fixes distutils removal)
    - Xvfb (virtual display — required for headed Chrome in headless servers)
    - selenium

INSTALL:
    pip install undetected-chromedriver selenium setuptools
    sudo apt install xvfb  (or: yum install xorg-x11-server-Xvfb)

ARCHITECTURE:
    Xvfb (virtual display :99)
      → Chrome 143 (headed, undetected)
        → perchance.org/mqgfwnim7o?apiToken=PERMANENT_TOKEN
          → Generator iframe (flat — images appear here)
            → <img src="data:image/jpeg;base64,...">

LICENSE: Free to use. No warranties.
"""

import os
import sys
import time
import base64
import hashlib
import logging
import subprocess
import argparse
from pathlib import Path
from datetime import datetime

# ═══════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════

# --- EDIT THESE TO MATCH YOUR SETUP ---

# Chrome binary path (must be Chrome 143)
CHROME_BIN = "/home/z/chrome-bin/chrome-143/chrome-linux64/chrome"

# ChromeDriver path (must match Chrome version)
CHROMEDRIVER = "/home/z/chrome-bin/chromedriver-linux64/chromedriver"

# Generator name (the slug after perchance.org/)
GENERATOR = "mqgfwnim7o"

# Your permanent API token (never expires, bypasses CF instantly)
API_TOKEN = "perm-agent-token-7h3k9p2q"

# Where to save generated images
OUTPUT_DIR = "./perchance_output"

# --- PERFORMANCE TUNING ---

MIN_IMAGE_SIZE = 20000     # 20KB minimum — filters out loading placeholders
MAX_WAIT_TIME = 60         # Max seconds to wait for images after clicking generate
DEFAULT_IMAGE_COUNT = 2    # How many unique images to collect per run
POLL_INTERVAL = 2         # Seconds between image polling checks

# Xvfb virtual display
XVFB_DISPLAY = ":99"
XVFB_RESOLUTION = "1280x720x24"

# ═══════════════════════════════════════════════════════════════════════════
# PROMPT TEMPLATES
# ═══════════════════════════════════════════════════════════════════════════

PROMPT_TEMPLATES = {
    "portrait": "beautiful anime woman portrait, highly detailed face, studio lighting, "
                "photorealistic, masterpiece, 8k",

    "fullbody": "full body view, beautiful anime woman standing gracefully, "
                "elegant outfit, detailed pose, natural lighting, masterpiece, 8k",

    "spicy": "beautiful anime woman, sensual pose, alluring expression, "
             "artistic, tasteful, photorealistic, masterpiece, 8k",

    "landscape": "breathtaking landscape, dramatic sky, volumetric lighting, "
                 "photorealistic, 8k, ultra detailed",

    "cyberpunk": "cyberpunk city at night, neon signs, rain-soaked streets, "
                 "futuristic architecture, photorealistic, 8k",

    "fantasy": "fantasy scene, magical forest, ethereal glow, mystical creatures, "
               "epic lighting, photorealistic, masterpiece, 8k",
}

# ═══════════════════════════════════════════════════════════════════════════
# LOGGING
# ═══════════════════════════════════════════════════════════════════════════

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    datefmt='%H:%M:%S',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('./perchance_pipeline.log', mode='a'),
    ]
)
log = logging.getLogger("PerchancePipeline")

# ═══════════════════════════════════════════════════════════════════════════
# PROCESS MANAGEMENT
# ═══════════════════════════════════════════════════════════════════════════

_xvfb_process = None


def kill_stale_processes():
    """Kill any leftover Chrome/Xvfb/chromedriver processes from previous runs."""
    log.debug("Cleaning stale processes...")
    subprocess.run(['pkill', '-9', '-x', 'chrome'], capture_output=True)
    subprocess.run(['pkill', '-9', '-x', 'chromedriver'], capture_output=True)
    subprocess.run(['pkill', '-9', '-x', 'Xvfb'], capture_output=True)
    time.sleep(1)
    log.debug("Stale processes cleaned")


def start_virtual_display(display=XVFB_DISPLAY, resolution=XVFB_RESOLUTION):
    """Start Xvfb virtual display for headed Chrome (bypasses CF detection)."""
    global _xvfb_process

    _xvfb_process = subprocess.Popen(
        ['Xvfb', display, '-screen', '0', resolution, '-ac', '-nolisten', 'tcp'],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )
    os.environ['DISPLAY'] = display
    time.sleep(1)
    log.info(f"Virtual display started on {display} ({resolution})")


def stop_virtual_display():
    """Terminate the Xvfb virtual display."""
    global _xvfb_process
    if _xvfb_process:
        try:
            _xvfb_process.terminate()
            _xvfb_process.wait(timeout=3)
        except Exception:
            try:
                _xvfb_process.kill()
            except Exception:
                pass
        log.debug("Virtual display stopped")


# ═══════════════════════════════════════════════════════════════════════════
# BROWSER SETUP
# ═══════════════════════════════════════════════════════════════════════════

def create_browser():
    """
    Create a stealthy Chrome instance using undetected-chromedriver.

    Key anti-detection measures:
    - Headed mode (not headless) via Xvfb — headless gets CF-blocked ~70%
    - WebDriver flag removed via CDP injection
    - Custom user-agent matching real Chrome 143
    - Automation-controlled features disabled
    """
    import undetected_chromedriver as uc

    opts = uc.ChromeOptions()
    opts.binary_location = CHROME_BIN

    # Stability & performance
    opts.add_argument('--no-sandbox')
    opts.add_argument('--disable-dev-shm-usage')
    opts.add_argument('--disable-gpu')
    opts.add_argument('--use-gl=swiftshader')
    opts.add_argument('--disable-extensions')
    opts.add_argument('--disable-popup-blocking')
    opts.add_argument('--window-size=1280,720')
    opts.add_argument('--lang=en-US,en')

    # Anti-detection
    opts.add_argument('--disable-blink-features=AutomationControlled')
    opts.add_argument(
        '--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'
    )

    driver = uc.Chrome(
        options=opts,
        driver_executable_path=CHROMEDRIVER,
        headless=False,            # MUST be False — headless gets CF-blocked
        use_subprocess=True,
        version_main=143,         # MUST match installed Chrome version
    )

    # Inject anti-detection scripts into every page load
    driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
        "source": """
            Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
            Object.defineProperty(navigator, 'languages', {get: () => ['en-US', 'en']});
            window.chrome = { runtime: {} };
        """
    })

    log.info("Chrome 143 browser ready (headed via Xvfb)")
    return driver


# ═══════════════════════════════════════════════════════════════════════════
# IMAGE GENERATION
# ═══════════════════════════════════════════════════════════════════════════

def generate(prompt, count=DEFAULT_IMAGE_COUNT, output_dir=OUTPUT_DIR,
             max_wait=MAX_WAIT_TIME, min_size=MIN_IMAGE_SIZE):
    """
    Generate images from a text prompt using the Perchance pipeline.

    Steps:
        1. Navigate to generator URL with API token (instant CF bypass)
        2. Wait for page load (CF challenge — usually instant with token)
        3. Switch to generator iframe (flat structure on mqgfwnim7o)
        4. Enter prompt into textarea
        5. Click the generate button (✨)
        6. Poll for base64-encoded images appearing as <img> elements
        7. Decode, deduplicate, and save to disk

    Args:
        prompt:      Text prompt for image generation
        count:        Number of unique images to collect
        output_dir:   Directory to save images
        max_wait:     Max seconds to wait for images after generate click
        min_size:     Minimum image size in bytes (filters placeholders)

    Returns:
        List of file paths to saved images
    """
    from selenium.webdriver.common.by import By

    Path(output_dir).mkdir(parents=True, exist_ok=True)

    # Build URL with API token for instant CF bypass
    url = f"https://perchance.org/{GENERATOR}?apiToken={API_TOKEN}"
    log.info(f"Navigating to generator...")
    log.info(f"  URL: {url}")

    driver = create_browser()
    t_start = time.time()

    try:
        # ── Step 1: Load page ──
        driver.get(url)

        # Wait for Cloudflare challenge (should be instant with API token)
        for i in range(15):
            page_title = driver.title.lower()
            if "just a moment" not in page_title:
                break
            time.sleep(1)
        else:
            log.error("Stuck on Cloudflare challenge page — CF bypass failed")
            return []

        cf_time = time.time() - t_start
        log.info(f"Cloudflare bypassed in {cf_time:.1f}s")
        time.sleep(2)

        # ── Step 2: Enter generator iframe ──
        # IMPORTANT: mqgfwnim7o has a FLAT iframe structure.
        # Images appear directly inside the generator iframe.
        # Do NOT look for a nested "image-generation" iframe — it doesn't exist.
        iframe_switched = False
        for iframe in driver.find_elements(By.TAG_NAME, "iframe"):
            src = iframe.get_attribute("src") or ""
            if iframe.is_displayed() and "perchance.org" in src and "?" in src:
                log.info("Switching to generator iframe...")
                driver.switch_to.frame(iframe)
                time.sleep(2)
                iframe_switched = True
                break

        if not iframe_switched:
            log.warning("Generator iframe not found — trying main page directly")

        iframe_time = time.time() - t_start
        log.info(f"Generator iframe ready in {iframe_time:.1f}s")

        # ── Step 3: Enter prompt ──
        textarea = None
        for ta in driver.find_elements(By.TAG_NAME, "textarea"):
            if ta.is_displayed():
                textarea = ta
                break

        if not textarea:
            log.error("No textarea found in generator — can't enter prompt")
            return []

        textarea.clear()
        textarea.send_keys(prompt)
        log.info(f"Prompt entered: \"{prompt[:80]}{'...' if len(prompt) > 80 else ''}\"")
        time.sleep(1)

        # ── Step 4: Click generate button ──
        generate_clicked = False
        for btn in driver.find_elements(By.TAG_NAME, "button"):
            if btn.is_displayed() and ("\u2728" in btn.text or "generate" in btn.text.lower()):
                btn.click()
                log.info("Generate button clicked")
                generate_clicked = True
                break

        if not generate_clicked:
            log.error("Generate button not found")
            return []

        gen_time = time.time() - t_start
        log.info(f"Generation triggered at {gen_time:.1f}s — waiting for images...")

        # ── Step 5: Poll for images ──
        # On mqgfwnim7o, images appear as <img> with data:image/jpeg;base64,...
        # directly in the generator iframe. No sub-iframe needed.
        saved_images = []
        seen_hashes = set()
        poll_start = time.time()

        while time.time() - poll_start < max_wait:
            try:
                images = driver.find_elements(
                    By.XPATH,
                    "//img[starts-with(@src, 'data:image/')]"
                )
            except Exception:
                images = []

            for img in images:
                src = img.get_attribute("src") or ""

                # Skip tiny data URIs (loading spinners, placeholders)
                if len(src) < 1000:
                    continue

                # Decode base64 image data
                try:
                    _, b64_data = src.split(",", 1)
                    image_bytes = base64.b64decode(b64_data)
                except Exception:
                    continue

                # Skip images below size threshold
                if len(image_bytes) < min_size:
                    continue

                # Deduplicate by content hash
                content_hash = hashlib.md5(image_bytes).hexdigest()
                if content_hash in seen_hashes:
                    continue
                seen_hashes.add(content_hash)

                # Determine file extension from MIME type
                mime = src.split(";")[0].split(":")[1] if ":" in src else "image/jpeg"
                ext = "png" if "png" in mime else "jpg"

                # Save to disk
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                filename = f"perchance_{timestamp}_{len(saved_images)+1:02d}.{ext}"
                filepath = os.path.join(output_dir, filename)

                with open(filepath, "wb") as f:
                    f.write(image_bytes)

                img_time = time.time() - t_start
                log.info(f"  Image #{len(saved_images)+1}: "
                         f"{len(image_bytes)//1024}KB saved at {img_time:.1f}s")
                saved_images.append(filepath)

                if len(saved_images) >= count:
                    break

            if len(saved_images) >= count:
                log.info(f"Collected {count} image(s) — done!")
                break

            # Progress indicator every 10s
            elapsed_poll = int(time.time() - poll_start)
            if elapsed_poll > 0 and elapsed_poll % 10 == 0:
                log.info(f"  [{elapsed_poll}s] Still waiting... "
                         f"{len(seen_hashes)} unique images so far")

            time.sleep(POLL_INTERVAL)

        total_time = time.time() - t_start
        log.info(f"Generation complete: {len(saved_images)} image(s) in {total_time:.1f}s")

        return saved_images

    except Exception as e:
        log.error(f"Generation failed: {e}")
        import traceback
        traceback.print_exc()
        return []

    finally:
        # Always clean up browser
        try:
            driver.quit()
        except Exception:
            pass
        stop_virtual_display()
        kill_stale_processes()
        log.info("Browser and processes cleaned up")


# ═══════════════════════════════════════════════════════════════════════════
# CLI INTERFACE
# ═══════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="Perchance Blitz Pipeline v8 — AI Image Generation",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=f"""
PROMPT TEMPLATES (--template):
  {', '.join(PROMPT_TEMPLATES.keys())}

EXAMPLES:
  python3 perchance_pipeline.py "a beautiful sunset over mountains"
  python3 perchance_pipeline.py "anime girl, silver hair" --count 4
  python3 perchance_pipeline.py --template spicy --count 4
  python3 perchance_pipeline.py --prompt-file my_prompts.txt --count 2
  python3 perchance_pipeline.py "portrait photo" --output ./my_images
  python3 perchance_pipeline.py "cat" --wait 90 --min-size 50000
        """
    )

    # Prompt input methods
    prompt_group = parser.add_mutually_exclusive_group(required=True)
    prompt_group.add_argument(
        "prompt", nargs="?", default=None,
        help="Image generation prompt (text)"
    )
    prompt_group.add_argument(
        "--template", "-t", choices=list(PROMPT_TEMPLATES.keys()),
        help="Use a built-in prompt template"
    )
    prompt_group.add_argument(
        "--prompt-file", "-f", type=str,
        help="Read prompt from a text file"
    )

    # Generation options
    parser.add_argument(
        "--count", "-n", type=int, default=DEFAULT_IMAGE_COUNT,
        help=f"Number of unique images to collect (default: {DEFAULT_IMAGE_COUNT})"
    )
    parser.add_argument(
        "--output", "-o", type=str, default=OUTPUT_DIR,
        help=f"Output directory for images (default: {OUTPUT_DIR})"
    )
    parser.add_argument(
        "--wait", "-w", type=int, default=MAX_WAIT_TIME,
        help=f"Max seconds to wait for images (default: {MAX_WAIT_TIME})"
    )
    parser.add_argument(
        "--min-size", type=int, default=MIN_IMAGE_SIZE,
        help=f"Minimum image size in bytes (default: {MIN_IMAGE_SIZE})"
    )

    args = parser.parse_args()

    # Resolve prompt
    if args.template:
        prompt = PROMPT_TEMPLATES[args.template]
        log.info(f"Using template: {args.template}")
    elif args.prompt_file:
        with open(args.prompt_file) as f:
            prompt = f.read().strip()
        log.info(f"Read prompt from file: {args.prompt_file}")
    else:
        prompt = args.prompt

    if not prompt:
        parser.error("No prompt provided")
        sys.exit(1)

    # Print banner
    banner = """
╔══════════════════════════════════════════════════════════════════════════════╗
║  PERCHANCE BLITZ PIPELINE v8                                               ║
║  Permanent Token · Flat Iframe · Chrome 143 · Xvfb                         ║
╚══════════════════════════════════════════════════════════════════════════════╝"""
    print(banner, flush=True)

    log.info(f"Prompt: \"{prompt[:100]}{'...' if len(prompt) > 100 else ''}\"")
    log.info(f"Images: {args.count} | Wait: {args.wait}s | Min size: {args.min_size//1024}KB")
    log.info(f"Output: {args.output}")
    print("-" * 78, flush=True)

    # Run pipeline
    t0 = time.time()
    saved = generate(
        prompt=prompt,
        count=args.count,
        output_dir=args.output,
        max_wait=args.wait,
        min_size=args.min_size,
    )
    total = time.time() - t0

    # Print results
    print("-" * 78, flush=True)
    if saved:
        print(f"\n  SUCCESS: {len(saved)} image(s) generated in {total:.1f}s", flush=True)
        print(f"  Output directory: {os.path.abspath(args.output)}\n", flush=True)
        for path in saved:
            size_kb = os.path.getsize(path) // 1024
            print(f"    {path}  ({size_kb}KB)", flush=True)
    else:
        print(f"\n  FAILED: No images generated in {total:.1f}s", flush=True)
        print("  Check perchance_pipeline.log for details.", flush=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
