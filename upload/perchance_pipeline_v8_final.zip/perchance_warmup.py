#!/usr/bin/env python3
"""
Perchance Pipeline v8 — Warmup Script

Keeps the browser session warm via scheduled cron jobs.
Runs a safe prompt through the full pipeline without saving images.
Designed to run every 8 minutes to maintain session freshness.

Usage:
    python3 perchance_warmup.py          (standalone)
    python3 -u perchance_warmup.py      (unbuffered for cron logging)

Cron setup (every 8 minutes):
    */8 * * * * cd /path/to/pipeline && python3 -u perchance_warmup.py >> warmup.log 2>&1
"""

import os
import sys
import time
import random
import subprocess
from pathlib import Path

LOG_FILE = "./perchance_warmup.log"
WARMUP_OUTPUT_DIR = "./perchance_output"

Path(WARMUP_OUTPUT_DIR).mkdir(parents=True, exist_ok=True)

# ── Configuration (same as main pipeline) ──
CHROME_BIN = "/home/z/chrome-bin/chrome-143/chrome-linux64/chrome"
CHROMEDRIVER = "/home/z/chrome-bin/chromedriver-linux64/chromedriver"
GENERATOR = "mqgfwnim7o"
API_TOKEN = "perm-agent-token-7h3k9p2q"
XVFB_DISPLAY = ":99"

# ── Safe warmup prompts (rotated randomly) ──
WARMUP_PROMPTS = [
    "a beautiful landscape, mountains, sunset, golden hour, photorealistic, 8k",
    "a cute cat playing with yarn ball, photorealistic, 8k, detailed",
    "futuristic city at night, cyberpunk, neon lights, rain reflections, 8k",
    "a cup of coffee on a wooden table, warm morning lighting, photorealistic",
    "beautiful ocean waves crashing on rocks, golden hour, photorealistic, 8k",
    "cherry blossom tree in spring, petals falling, soft pink light, 8k",
    "cozy bookshelf with warm lamp, old books, wooden furniture, 8k",
]


def log(msg):
    """Log to both console and log file."""
    ts = time.strftime('%Y-%m-%d %H:%M:%S')
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    try:
        with open(LOG_FILE, "a") as f:
            f.write(line + "\n")
    except Exception:
        pass


def run_warmup():
    """Execute a single warmup cycle through the Perchance pipeline."""
    log("=== WARMUP START ===")

    # Clean stale processes
    subprocess.run(['pkill', '-9', '-x', 'chrome'], capture_output=True)
    subprocess.run(['pkill', '-9', '-x', 'chromedriver'], capture_output=True)
    subprocess.run(['pkill', '-9', '-x', 'Xvfb'], capture_output=True)
    time.sleep(1)

    # Start virtual display
    xvfb = subprocess.Popen(
        ['Xvfb', XVFB_DISPLAY, '-screen', '0', '1280x720x24', '-ac', '-nolisten', 'tcp'],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )
    os.environ['DISPLAY'] = XVFB_DISPLAY
    time.sleep(1)

    try:
        import undetected_chromedriver as uc
        from selenium.webdriver.common.by import By

        opts = uc.ChromeOptions()
        opts.binary_location = CHROME_BIN
        opts.add_argument('--no-sandbox')
        opts.add_argument('--disable-dev-shm-usage')
        opts.add_argument('--disable-blink-features=AutomationControlled')
        opts.add_argument('--disable-extensions')
        opts.add_argument('--window-size=1280,720')
        opts.add_argument('--disable-gpu')

        driver = uc.Chrome(
            options=opts,
            driver_executable_path=CHROMEDRIVER,
            headless=False,
            use_subprocess=True,
            version_main=143,
        )
        driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
            "source": "Object.defineProperty(navigator, 'webdriver', {get: () => undefined});"
        })

        # Navigate with API token
        url = f"https://perchance.org/{GENERATOR}?apiToken={API_TOKEN}"
        t0 = time.time()
        driver.get(url)

        # Wait for CF
        for i in range(15):
            if "just a moment" not in driver.title.lower():
                break
            time.sleep(1)

        log(f"CF bypass: {time.time()-t0:.1f}s")
        time.sleep(2)

        # Enter generator iframe (flat structure)
        for iframe in driver.find_elements(By.TAG_NAME, "iframe"):
            src = iframe.get_attribute("src") or ""
            if iframe.is_displayed() and "perchance.org" in src and "?" in src:
                driver.switch_to.frame(iframe)
                time.sleep(2)
                break

        # Enter random safe prompt
        prompt = random.choice(WARMUP_PROMPTS)
        for ta in driver.find_elements(By.TAG_NAME, "textarea"):
            if ta.is_displayed():
                ta.clear()
                ta.send_keys(prompt)
                time.sleep(1)
                break

        log(f"Prompt: {prompt[:60]}")

        # Click generate
        for btn in driver.find_elements(By.TAG_NAME, "button"):
            if btn.is_displayed() and ("\u2728" in btn.text or "generate" in btn.text.lower()):
                btn.click()
                log("Generate clicked")
                break

        # Wait for generation to process (don't save images)
        time.sleep(12)

        elapsed = time.time() - t0
        log(f"WARMUP COMPLETE: {elapsed:.1f}s")

        driver.quit()

    except Exception as e:
        log(f"WARMUP ERROR: {e}")

    finally:
        try:
            xvfb.terminate()
        except Exception:
            pass

    log("=== WARMUP END ===")
    return True


if __name__ == "__main__":
    run_warmup()
