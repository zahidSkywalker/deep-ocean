// Omni Play — MongoDB connection using native driver (not mongoose)

import { MongoClient, Db, Collection } from 'mongodb';

const MONGODB_URI = process.env.MONGODB_URI;
if (!MONGODB_URI) throw new Error('MONGODB_URI environment variable is required');
const MONGO_URI = MONGODB_URI as string;
const DB_NAME = 'diana_iptv';

// Singleton connection
let cachedClient: MongoClient | null = null;
let cachedDb: Db | null = null;

export interface CachedChannel {
  id: string;
  name: string;
  url: string;
  logo: string;
  category: string;
  country: string;
  tvgId?: string;
  tvgName?: string;
  sourceTag?: string;
  quality?: string;
}

export interface CachedFavorite {
  deviceId: string;
  channelId: string;
  channelName: string;
  addedAt: string;
}

export interface CachedRecent {
  deviceId: string;
  channelId: string;
  channelName: string;
  watchedAt: string;
  logo?: string;
  category?: string;
  country?: string;
  url?: string;
}

export interface ChannelCache {
  _id: string;
  channels: CachedChannel[];
  total: number;
  countries: string[];
  categories: string[];
  updatedAt: string;
}

declare global {
  var mongoClient: MongoClient | undefined;
}

export async function getDb(): Promise<Db> {
  if (cachedDb) return cachedDb;

  if (cachedClient) {
    cachedDb = cachedClient.db(DB_NAME);
    return cachedDb;
  }

  // Use global to preserve across hot reloads in development
  if (global.mongoClient) {
    cachedClient = global.mongoClient;
    cachedDb = cachedClient.db(DB_NAME);
    return cachedDb;
  }

  const client = new MongoClient(MONGO_URI);
  await client.connect();
  global.mongoClient = client;
  cachedClient = client;
  cachedDb = client.db(DB_NAME);

  // Create indexes
  try {
    await createIndexes(cachedDb);
  } catch (err) {
    console.error('[MongoDB] Error creating indexes:', err);
  }

  return cachedDb;
}

async function createIndexes(db: Db): Promise<void> {
  const channelCache = db.collection('channel_cache');

  // Create TTL index for cache (auto-expire after 6 hours)
  await channelCache.createIndex(
    { updatedAt: 1 },
    { expireAfterSeconds: 6 * 60 * 60, name: 'cache_ttl' }
  );

  const favorites = db.collection('favorites');
  await favorites.createIndex({ deviceId: 1, channelId: 1 }, { unique: true, name: 'fav_device_channel' });
  await favorites.createIndex({ deviceId: 1 }, { name: 'fav_device' });

  const recent = db.collection('recent');
  await recent.createIndex({ deviceId: 1, channelId: 1 }, { name: 'recent_device_channel' });
  await recent.createIndex({ deviceId: 1 }, { name: 'recent_device' });
  await recent.createIndex(
    { watchedAt: 1 },
    { expireAfterSeconds: 30 * 24 * 60 * 60, name: 'recent_ttl' } // 30 days TTL
  );
}

export function getChannelCacheCollection(db: Db): Collection<ChannelCache> {
  return db.collection<ChannelCache>('channel_cache');
}

export function getFavoritesCollection(db: Db): Collection<CachedFavorite> {
  return db.collection<CachedFavorite>('favorites');
}

export function getRecentCollection(db: Db): Collection<CachedRecent> {
  return db.collection<CachedRecent>('recent');
}

export function sanitizeString(input: unknown, maxLength = 100): string {
  if (typeof input !== 'string') return '';
  // Strip control characters, HTML tags, and dangerous patterns
  let cleaned = input
    .replace(/[\x00-\x1F\x7F]/g, '') // control chars
    .replace(/[<>{}$]/g, '')           // HTML chars + NoSQL operator prefix
    .trim();
  return cleaned.slice(0, maxLength);
}
