// ─── NextAuth.js v5 Route Handler ─────────────────────────────
// Catch-all route for NextAuth authentication endpoints.
// GET: handles sign-in redirects, OAuth callbacks, session checks
// POST: handles credentials sign-in, session updates

export { GET, POST } from "@/lib/auth";
